package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import model.Hoodie;
import model.User;
import util.DatabaseConnect;

public class HomeScene extends Application{
	
	Scene homescene;
	BorderPane bp;
	GridPane gp;
	
	Label lbljudul,lbldetail, lblid,lblname, lblprice, lblqty, lbltotprice, lblnoselect;
	
	Spinner<Integer> spinqty;
	Button btadd;
	ListView<Hoodie> lv;
	MenuBar menubar;
	MenuItem logoutitem, homeitem, cartitem, historyitem;
	Menu accountmenu, menu;
	Stage homestage;
	
	private Hoodie selectedHoodie;
	private User currentuser;
	
	
	public static void main(String[] args) {
		launch(args);

	}
	
	public HomeScene(User currentuser) {
        this.currentuser = currentuser;
    }

	@Override
	public void start(Stage homestage) throws Exception {
		
		this.homestage = homestage; 
		Initialize();
		layout();
		Action();
		displayHoodie();
		homescene = new Scene (bp, 700, 600);
		homestage.setTitle("hO-Odie");
		homestage.setScene(homescene);
		homestage.show();
		
		
	}
	
	private void displayHoodie(){
		
		hoodieListView();
		
		 lv.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Hoodie>() {
	            @Override
	            public void changed(ObservableValue<? extends Hoodie> observable, Hoodie oldValue, Hoodie newValue) {
	                if (newValue != null) {
	                    selectedHoodie = newValue;
	                    updateDetails();
	                } else {
	                    selectedHoodie = null;
	                    
	                }
	            }

				private void updateDetails() {
					lblid.setText("Hoodie ID: " + selectedHoodie.getHoodieID());
			        lblname.setText("Name: " + selectedHoodie.getHoodieName());
			        lblprice.setText("Price: " + selectedHoodie.getHoodiePrice());
			        updateTotalPrice();
			        
			        gp.add(lblid, 2, 2);
					gp.add(lblname, 2, 3);
					gp.add(lblprice, 2, 4);
					gp.add(lblqty , 2, 5);
					HBox hb = new HBox ();
					hb.getChildren().addAll(spinqty,lbltotprice);
					hb.setSpacing(5);
					gp.add(hb , 2, 6);
					gp.add(btadd , 2, 7);

			        spinqty.valueProperty().addListener((observable, oldValue, newValue) -> {
			            updateTotalPrice();
			        });

			        lblnoselect.setVisible(false);
			        btadd.setDisable(false);
					
				}

				private void updateTotalPrice() {
					int quantity = spinqty.getValue();
			        double totalPrice = selectedHoodie.getHoodiePrice() * quantity;
			        lbltotprice.setText("Total Price: " + String.format("%.2f", totalPrice));
				}
				
	        });
	}
	

	private void hoodieListView() {
		try (Connection connection = DatabaseConnect.getConnection();
	             Statement statement = connection.createStatement();
	             ResultSet resultSet = statement.executeQuery("SELECT * FROM hoodie")) {

	            ObservableList<Hoodie> hoodieList = FXCollections.observableArrayList();

	            while (resultSet.next()) {
	                String hoodieID = resultSet.getString("HoodieID");
	                String hoodieName = resultSet.getString("HoodieName");
	                double hoodiePrice = resultSet.getDouble("HoodiePrice");

	                hoodieList.add(new Hoodie(hoodieID, hoodieName, hoodiePrice));
	            }

	            lv.setItems(hoodieList);

	        } catch (SQLException ex) {
	            showErrorAlert("Error fetching hoodie data from the database: " + ex.getMessage());
	        }
		
	}

	private void Action() {
		cartitem.setOnAction(e -> {
            CartScene cartscene = new CartScene(currentuser);
            try {
				cartscene.start(homestage);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
        });

		historyitem.setOnAction(e -> {
            HistoryScene historyscene = new HistoryScene(currentuser);
            try {
				historyscene.start(homestage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        });
		
		logoutitem.setOnAction(e -> {
			
			LoginScene loginscene = new LoginScene();
			try {
				loginscene.start(homestage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		});
		
		btadd.setOnAction(e -> {
			addToCart();
		});
		
	}

	private void addToCart() {
		if (selectedHoodie != null ) {
		
	        int quantity = spinqty.getValue();
	        String query = "INSERT INTO cart (UserID ,HoodieID, Quantity) VALUES (?, ?, ?)";
	        
	        try (Connection connection = DatabaseConnect.getConnection();
	             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

	            preparedStatement.setString(1, currentuser.getUserid());
	            preparedStatement.setString(2, selectedHoodie.getHoodieID());
	            preparedStatement.setInt(3, quantity);

	            
	            int rowsAffected = preparedStatement.executeUpdate();

	            if (rowsAffected > 0) {
	            	System.out.println("OK");
	                showSuccesAlert("Product successfully added to the cart!");
	            }else {
	            	System.out.println("NO");
	                showErrorAlert("Failed to add product to the cart.");
	            }

	        } catch (SQLException ex) {
	            showErrorAlert("Error adding product to the cart: " + ex.getMessage());
	        }
	    } 
	}
	
		
	

	private void showErrorAlert(String message) {
	    Alert alert = new Alert(Alert.AlertType.ERROR);
	    alert.setTitle("Error");
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.showAndWait();
	}
	
	private void showSuccesAlert(String message) {
	    Alert alert = new Alert(Alert.AlertType.INFORMATION);
	    alert.setTitle("Success");
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.showAndWait();
	}
	
	

	private void layout() {
		
		gp.add(lbljudul, 0, 0, 5, 1);
		gp.add(lv, 0, 1, 1, 8);
		gp.add(lbldetail, 2,1);
		gp.add(lblnoselect, 2, 2);
		
		
		gp.setPadding(new Insets(10));
		gp.setHgap(10);
		gp.setVgap(5);
		
	}


	private void Initialize() {
	
		gp = new GridPane();
		bp = new BorderPane(gp);
		gp.setAlignment(Pos.CENTER);
		
		
		lv = new ListView<Hoodie>();
		
		lbljudul = new Label ("hO-Ohdie");
		lbljudul.setStyle("-fx-font-size: 40; -fx-font-style: italic;");
		lbldetail = new Label ("Hoodie's Detail");
		lbldetail.setStyle("-fx-font-size: 40; -fx-font-weight: bold; -fx-font-style: italic;");
		lblid = new Label ("Hoodie ID: ");
		lblname = new Label ("Name: ");
		lblprice = new Label ("Price: ");
		lblqty = new Label ("Quantity: ");
		lbltotprice = new Label ("Total Price: ");
		lblnoselect = new Label ("Select an Item from the List");
		
		btadd = new Button ("Add to Cart");
		
		spinqty = new Spinner<> ();
		spinqty.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 1));
		
		menubar = new MenuBar();
		
		accountmenu = new Menu ("Account");
		logoutitem = new MenuItem ("Log Out");
		
		menu = new Menu ("User");
		homeitem = new MenuItem ("Home");
		cartitem = new MenuItem ("Cart");
		historyitem = new MenuItem ("History");
		
		accountmenu.getItems().addAll(logoutitem);
		menu.getItems().addAll(homeitem, cartitem, historyitem);
		
		menubar.getMenus().addAll(accountmenu, menu);
		
		bp = new BorderPane (gp);
		bp.setTop(menubar);
		
	}
	
	
}
