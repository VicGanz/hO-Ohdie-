package model;

public class Hoodie  {

	private String HoodieID;
	private String HoodieName;
	private double HoodiePrice;
	
	

	public Hoodie(String hoodieID, String hoodieName, double hoodiePrice) {
		super();
		this.HoodieID = hoodieID;
		this.HoodieName = hoodieName;
		this.HoodiePrice = hoodiePrice; 
		
	}

	public String getHoodieID() {
		return HoodieID;
	}

	public void setHoodieID(String hoodieID) {
		HoodieID = hoodieID;
	}

	public String getHoodieName() {
		return HoodieName;
	}

	public void setHoodieName(String hoodieName) {
		HoodieName = hoodieName;
	}

	public double getHoodiePrice() {
		return HoodiePrice;
	}

	public void setHoodiePrice(double hoodiePrice) {
		HoodiePrice = hoodiePrice;
	}
	
	public String toString() {
        return HoodieID + " - " + HoodieName; 
    }
	
	
	
}

