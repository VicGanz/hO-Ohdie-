package model;

public class Cart {
	
	private String HoodieID;
	private String HoodieName;
	private double HoodiePrice;
	private int Quantity;
	private double TotalPrice;
	
	
	
	public Cart(String hoodieID, String hoodieName, double hoodiePrice, int quantity, double totalPrice) {
		super();
		HoodieID = hoodieID;
		HoodieName = hoodieName;
		HoodiePrice = hoodiePrice;
		Quantity = quantity;
		TotalPrice = totalPrice;
		
		
	}
	
	public void setTotalPrice(double totalPrice) {
		TotalPrice = totalPrice;
	}

	public String getHoodieID() {
		return HoodieID;
	}
	public void setHoodieID(String hoodieID) {
		HoodieID = hoodieID;
	}
	public String getHoodieName() {
		return HoodieName;
	}
	public void setHoodieName(String hoodieName) {
		HoodieName = hoodieName;
	}
	public double getHoodiePrice() {
		return HoodiePrice;
	}
	public void setHoodiePrice(double hoodiePrice) {
		HoodiePrice = hoodiePrice;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	
	public double getTotalPrice() {
        return TotalPrice;
    }
	

}
