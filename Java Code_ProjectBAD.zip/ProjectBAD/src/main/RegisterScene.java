package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import util.DatabaseConnect;

public class RegisterScene extends Application {
	
	BorderPane bp;
	GridPane gp;
	Scene registerScene;
	Label registerlbl, emaillbl, usernamelbl, passwordlbl, confirmpasswordlbl,phonenumberlbl, genderlbl ,addresslbl;
	TextField emailfield, usernamefield, phonenumberfield ;
	PasswordField passwordfield, confirmpassfield ;
	RadioButton malerb, femalerb;
	TextArea addressta;
	CheckBox cbterms;
	Button registerbutton;
	MenuBar menubar;
	MenuItem loginitem;
	Menu filemenu;
	Stage Registerstage;
	
	public static void main(String[] args) {
		launch (args);

	}

	@Override
	public void start(Stage Registerstage) throws Exception {
		this.Registerstage = Registerstage;
		initialize();
		Action();
		registerScene = new Scene (bp,700,600);
		Registerstage.setTitle("hO-Ohdie");
		Registerstage.setScene(registerScene);
		Registerstage.show();
	
	}

	private void Action() {

		loginitem.setOnAction(e -> {
			LoginScene loginscene = new LoginScene ();
			try {
				loginscene.start(Registerstage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		
		 registerbutton.setOnAction(e -> {
		       if (validateRegistration()) {
		           addData();
		        }
		    });
    }
	
	
	
	private String generateUserId() {
	    int randomNumber = (int) (Math.random() * 900) + 100;
	    return "US" + randomNumber;
	}

    private boolean validateRegistration() {
     
        String userIdRegex = "US\\d{3}";
        String userId = generateUserId();

        if (!userId.matches(userIdRegex)) {
            showErrorAlert("Invalid User ID format");
            return false;
        }
        
        String emailRegex = "^.+@hoohdie\\.com$";
        String email = emailfield.getText();

        if (!email.matches(emailRegex)) {
        	showErrorAlert("Invalid email format. Email must end with '@hoohdie.com'");
            return false;
        }

        String username = usernamefield.getText();
        if (!isUsernameUnique(username)) {
        	showErrorAlert("Username already taken");
            return false;
        }
        
        String password = passwordfield.getText();

        if (password.length() < 5) {
        	showErrorAlert("Password must contain at least 5 characters");
            return false;
        }
        
        if (!password.equals(confirmpassfield.getText())) {
        	showErrorAlert("Password and Confirm Password do not match");
            return false;
        }
     
        String phoneNumberRegex = "^\\+62\\d{11}$";
        String phoneNumber = phonenumberfield.getText();

        if (!phoneNumber.matches(phoneNumberRegex)) {
        	showErrorAlert("Invalid phone number format. Must start with '+62' and have 14 digits");
            return false;
        }
        
        if (!malerb.isSelected() && !femalerb.isSelected()) {
        	showErrorAlert("Please select a gender");
            return false;
        }
     
        if (addressta.getText().isEmpty()) {
        	showErrorAlert("Please provide an address");
            return false;
        }
        
        if (!cbterms.isSelected()) {
        	showErrorAlert("Please agree to terms & conditions");
            return false;
        }

        return true;
    }
    
    private boolean isUsernameUnique(String username) {
    	try (Connection connection = DatabaseConnect.getConnection()) {
            String query = "SELECT * FROM user WHERE Username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    return !resultSet.next();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showErrorAlert("Database error");
            return false;
        }
    }
    
    private void addData() {
    	String userid = generateUserId();
    	String email = emailfield.getText();
    	String username = usernamefield.getText();
    	String password = passwordfield.getText();
    	String phonenumber = phonenumberfield.getText();
    	String address = addressta.getText();
    	ToggleGroup genderGroup = new ToggleGroup();
    	malerb.setToggleGroup(genderGroup);
        femalerb.setToggleGroup(genderGroup);
        String gender = "";
        RadioButton selectedRadioButton = (RadioButton) genderGroup.getSelectedToggle();
        if (selectedRadioButton != null) {
            gender = selectedRadioButton.getText();
        }
    	String role = "User";
    	
    	String query = "INSERT INTO user (UserID, Email, Username, Password, PhoneNumber, Address, Gender, Role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    	 try (Connection connection = DatabaseConnect.getConnection()) {
             try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                 preparedStatement.setString(1, userid);
                 preparedStatement.setString(2, email);
                 preparedStatement.setString(3, username);
                 preparedStatement.setString(4, password);
                 preparedStatement.setString(5, phonenumber);
                 preparedStatement.setString(6, address);
                 preparedStatement.setString(7, gender);
                 preparedStatement.setString(8, role);
                 
                 int rowsAffected = preparedStatement.executeUpdate();

                 if (rowsAffected > 0) {
                	 LoginScene loginscene = new LoginScene ();
         			try {
         				loginscene.start(Registerstage);
         			} catch (Exception e1) {
         				// TODO Auto-generated catch block
         				e1.printStackTrace();
         			}
                 } else {
                     showErrorAlert("Failed to insert data.");
                 }
             }
         } catch (SQLException e) {
             e.printStackTrace();
             System.out.println("Database error: " + e.getMessage());
         }
     }
    	
    

    private void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
		
	private void initialize() {
		
		registerlbl = new Label ("REGISTER");
		emaillbl = new Label ("Email: ");
		usernamelbl = new Label ("Username:");
		passwordlbl = new Label ("Password:");
		confirmpasswordlbl = new Label ("Confirm Password:");
		phonenumberlbl = new Label ("Phone Number:");
		genderlbl = new Label ("Gender:");
		addresslbl = new Label ("Address:");
		
		emailfield = new TextField ();
		emailfield.setPromptText("Input Email");
		usernamefield = new TextField ();
		usernamefield.setPromptText("Input an Unique Username");
		phonenumberfield = new TextField();
		phonenumberfield.setPromptText("Example: +6212345678901");
		passwordfield = new PasswordField ();
		passwordfield.setPromptText("Input Passoword");
		confirmpassfield = new PasswordField();
		confirmpassfield.setPromptText("Confirm Password");
		malerb = new RadioButton ("Male");
		femalerb = new RadioButton ("Female");
		addressta = new TextArea ();
		addressta.setPromptText("Input Address");
		cbterms = new CheckBox ("I Agree to terms & Condition");
		
		registerbutton = new Button ("Register");
		registerbutton.setMinWidth(150);
		
		ToggleGroup genderGroup = new ToggleGroup();
		malerb.setToggleGroup(genderGroup);
		femalerb.setToggleGroup(genderGroup);
		
		HBox hb = new HBox (10);
		hb.getChildren().addAll(malerb, femalerb);
		HBox hbbt = new HBox(10);
		hbbt.getChildren().addAll(registerbutton);
		hbbt.setAlignment(Pos.BOTTOM_RIGHT);
	
		gp = new GridPane ();
		gp.add(registerlbl, 0, 0,2,1);
		registerlbl.setStyle("-fx-font-size: 50; -fx-font-weight: bold; -fx-font-style: italic;");
		gp.add(emaillbl, 0, 1);
		emaillbl.setStyle("-fx-font-weight: bold;");
		gp.add(emailfield, 0, 2);
		gp.add(usernamelbl, 0, 3);
		usernamelbl.setStyle("-fx-font-weight: bold;");
		gp.add(usernamefield, 0, 4);
		gp.add(passwordlbl, 0, 5);
		passwordlbl.setStyle("-fx-font-weight: bold;");
		gp.add(passwordfield, 0 , 6);
		gp.add(confirmpasswordlbl, 0, 7);
		confirmpasswordlbl.setStyle("-fx-font-weight: bold;");
		gp.add(confirmpassfield, 0, 8);
		gp.add(phonenumberlbl, 0, 9);
		phonenumberlbl.setStyle("-fx-font-weight: bold;");
		gp.add(phonenumberfield, 0, 10);
		gp.add(genderlbl, 0, 11);
		genderlbl.setStyle("-fx-font-weight: bold;");
		gp.add(hb, 0, 12);
		gp.add(addresslbl, 0, 13);
		addresslbl.setStyle("-fx-font-weight: bold;");
		gp.add(addressta, 0, 14);
		gp.add(cbterms, 0, 15);
		gp.add(hbbt, 0, 16);
		registerbutton.setMaxWidth(150);
		gp.setAlignment(Pos.CENTER);	
		
		gp.setPadding(new Insets (10));
		gp.setHgap(10);
		gp.setVgap(5);
		
		menubar = new MenuBar ();
		filemenu = new Menu ("Register");
		loginitem = new MenuItem("Login");
		filemenu.getItems().addAll(loginitem);
		menubar.getMenus().add(filemenu);
		
		bp = new BorderPane (gp);
		bp.setTop(menubar);
		
	}

}
