package model;

public class Transaction {
	
	private String TransactionID;
	private String UserID;
	
	public Transaction(String transactionID, String userID) {
		super();
		TransactionID = transactionID;
		UserID = userID;
	}

	public String getTransactionID() {
		return TransactionID;
	}

	public void setTransactionID(String transactionID) {
		TransactionID = transactionID;
	}

	public String getUserID() {
		return UserID;
	}

	public void setUserID(String userID) {
		UserID = userID;
	}
	
	

	
}
