package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.Cart;
import model.User;
import util.DatabaseConnect;

public class CartScene extends Application {
	
	Scene cartscene;
	BorderPane bp;
	GridPane gp;
	
	Label lbljudul, lbldetail, lblid, lblname, lblprice, lblqty, lbltotprice, lblcontact, lblemail, lblphone, lbladdress, lblcarttot ,lblnone;
	TableView<Cart> tv;
	Button btco, btremovecart;
	MenuBar menubar;
	MenuItem logoutitem, homeitem, cartitem, historyitem;
	Menu accountmenu, menu;
	Stage cartstage;
	
	private Cart selectedCart;
	private User currentuser;

	public static void main(String[] args) {
		launch(args);

	}
	
	public CartScene(User currentuser) {
        this.currentuser = currentuser;
    }

	@Override
	public void start(Stage cartstage) throws Exception {
		
		this.cartstage = cartstage;
		Initialize();
		Layout();
		Action();
		displayUserCart();
		cartscene = new Scene (bp, 700, 600);
		cartstage.setTitle("hO-Odie");
		cartstage.setScene(cartscene);
		cartstage.show();
	}
	
	private void displayUserCart() {
		
		
		getCartData(currentuser);
		
		tv.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                updateDetails(newSelection);
            } else {
                hideDetails();
            }
        });
		
		TableColumn<Cart, String> hoodieID = new TableColumn<>("Hoodie ID");
        hoodieID.setCellValueFactory(new PropertyValueFactory<>("HoodieID"));
        hoodieID.setPrefWidth(100);

        TableColumn<Cart, String> hoodieName = new TableColumn<>("Hoodie Name");
        hoodieName.setCellValueFactory(new PropertyValueFactory<>("HoodieName"));
        hoodieName.setPrefWidth(100);

        TableColumn<Cart, Integer> quantity = new TableColumn<>("Quantity");
        quantity.setCellValueFactory(new PropertyValueFactory<>("Quantity")); 
        quantity.setPrefWidth(70);

        TableColumn<Cart, Double> totalPrice = new TableColumn<>("Total Price");
        totalPrice.setCellValueFactory(new PropertyValueFactory<>("TotalPrice"));
        totalPrice.setPrefWidth(100);

        tv.getColumns().addAll(hoodieID, hoodieName, quantity, totalPrice);
        
        ObservableList<Cart> cartList = getCartData(currentuser);
        tv.setItems(cartList);

	}
	
	private void hideDetails() {
			lblnone.setVisible(true);
			lblid.setVisible(false);
	        lblname.setVisible(false);
	        lblprice.setVisible(false);
	        lblqty.setVisible(false);
	        lbltotprice.setVisible(false);
	        btremovecart.setVisible(false);
		
	}

	private void updateDetails(Cart selectedCart) {
	   lblid.setText("Hoodie ID: " + selectedCart.getHoodieID());
       lblname.setText("Name: " + selectedCart.getHoodieName());
       lblprice.setText("Price: " + selectedCart.getHoodiePrice());
       lblqty.setText("Quantity: " + selectedCart.getQuantity());
       
       int quantity = selectedCart.getQuantity();
       double totalPrice = selectedCart.getHoodiePrice() * quantity;
       lbltotprice.setText("Total Price: " + String.format("%.2f", totalPrice));
       
       ObservableList<Cart> cartList = getCartData(currentuser);
       double cartTotal = calculateCartTotal(cartList);
       lblcarttot.setText("Cart's Total Price: " + String.format("%.2f", cartTotal));


       gp.add(lblid, 1, 2);
       gp.add(lblname, 1, 3);
       gp.add(lblprice, 1, 4);
       gp.add(lblqty, 1, 5);
       gp.add(lbltotprice, 1, 6);
       gp.add(btremovecart, 1, 7);
       
       lblnone.setVisible(false);
       btremovecart.setVisible(true);
		
	}

	private ObservableList<Cart> getCartData(User currentUser) {
	    try (Connection connection = DatabaseConnect.getConnection();
	         PreparedStatement preparedStatement = connection.prepareStatement(
	                 "SELECT h.HoodieID, h.HoodieName, h.HoodiePrice, c.Quantity, "
	                 + "(c.Quantity * h.HoodiePrice) AS 'Total Price' FROM hoodie h "
	                 + "JOIN cart c ON c.HoodieID = h.HoodieID WHERE c.UserID = ?")) {

	        preparedStatement.setString(1, currentUser.getUserid());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            ObservableList<Cart> cartList = FXCollections.observableArrayList();

	            while (resultSet.next()) {
	                String hoodieID = resultSet.getString("HoodieID");
	                String hoodieName = resultSet.getString("HoodieName");
	                double hoodiePrice = resultSet.getDouble("HoodiePrice");
	                int quantity = resultSet.getInt("Quantity");
	                double totalPrice = resultSet.getDouble("Total Price");

	                cartList.add(new Cart(hoodieID, hoodieName, hoodiePrice, quantity, totalPrice));
	                
	            }
	            return cartList;
	        }

	    } catch (SQLException ex) {
	        showErrorAlert("Database Error: " + ex.getMessage());
	    }
	    return FXCollections.observableArrayList();
	}
	

	private double calculateCartTotal(ObservableList<Cart> cartList) {
		double total = 0.0;
	    for (Cart cart : cartList) {
	        total += cart.getTotalPrice();
	    }
	    return total;
	}

	private void showErrorAlert(String message) {
	    Alert alert = new Alert(Alert.AlertType.ERROR);
	    alert.setTitle("Error");
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.showAndWait();
	}
	
	private void showSuccesAlert(String message) {
	    Alert alert = new Alert(Alert.AlertType.INFORMATION);
	    alert.setTitle("Success");
	    alert.setHeaderText("Massage");
	    alert.setContentText(message);
	    alert.showAndWait();
	}


	private void Action() {
		
		homeitem.setOnAction(e -> {
            HomeScene homescene = new HomeScene(currentuser);
            try {
            	homescene.start(cartstage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        });
		
		
		historyitem.setOnAction(e -> {
            HistoryScene historyscene = new HistoryScene(currentuser);
            try {
				historyscene.start(cartstage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        });
		
		logoutitem.setOnAction(e ->{
			
			LoginScene loginscene = new LoginScene();
			try {
				loginscene.start(cartstage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		});
		
		btco.setOnAction(e -> {
			
			ObservableList<Cart> cartList = getCartData(currentuser);

	        if (cartList.isEmpty()) {
	            showErrorAlert("Your cart is empty. Add items to the cart before checking out.");
	            return;
	        }
	        paymentConfirmationPopup();
	    });
		
		btremovecart.setOnAction(e -> {
			DeleteCart();
		});
		
	}
	
	private String generateTransactionID() {
	    int randomNumber = (int) (Math.random() * 900) + 100;
	    return "TR" + randomNumber;
	}
	
	private void completeCheckout() {

	    ObservableList<Cart> cartList = getCartData(currentuser);

	    if (cartList.isEmpty()) {
	        showErrorAlert("Your cart is empty. Add items to the cart before checking out.");
	        return;
	    }
	    try (Connection connection = DatabaseConnect.getConnection()) {
	        String transactionID = generateTransactionID();
	        String insertTransactionQuery = "INSERT INTO transactionheader (TransactionID, UserID) VALUES (?, ?)";
	        try (PreparedStatement transactionStatement = connection.prepareStatement(insertTransactionQuery)) {
	            transactionStatement.setString(1, transactionID);
	            transactionStatement.setString(2, currentuser.getUserid());
	            transactionStatement.executeUpdate();
	        }

	        moveCartToTransactionDetails(transactionID, cartList);
	        clearCart();
	        tv.getItems().clear();
	        showSuccesAlert(currentuser.getUsername() + " successfully made a Transaction! TransactionID: " + transactionID);
	    } catch (SQLException ex) {
	        showErrorAlert("Error completing the checkout: " + ex.getMessage());
	    }
	}



	private void clearCart() {
		try (Connection connection = DatabaseConnect.getConnection();
		         PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM cart WHERE UserID = ?")) {

		        preparedStatement.setString(1, currentuser.getUserid());
		        preparedStatement.executeUpdate();
		    } catch (SQLException ex) {
		        showErrorAlert("Error clearing the cart: " + ex.getMessage());
		    }
		
	}

	private void moveCartToTransactionDetails(String transactionID, ObservableList<Cart> cartList) {

		try (Connection connection = DatabaseConnect.getConnection()) {
	        String query = "INSERT INTO transactiondetail (TransactionID, HoodieID, Quantity) VALUES (?, ?, ?)";
	        try (PreparedStatement transactionDetailsStatement = connection.prepareStatement(query)) {
	            for (Cart cart : cartList) {
	                transactionDetailsStatement.setString(1, transactionID);
	                transactionDetailsStatement.setString(2, cart.getHoodieID());
	                transactionDetailsStatement.setInt(3, cart.getQuantity());
	                transactionDetailsStatement.executeUpdate();
	            }
	        }
	    } catch (SQLException ex) {
	        showErrorAlert("Error transaction details: " + ex.getMessage());
	    }
		
	}

	private void paymentConfirmationPopup() {
		
			Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
		    confirmationAlert.setTitle("Payment Confirmation");
		    confirmationAlert.setHeaderText(null);
		    confirmationAlert.setContentText("Are you sure you want to complete the payment?");
		    
		    ButtonType makePaymentButton = new ButtonType("Make Payment", ButtonData.OK_DONE);
		    confirmationAlert.getButtonTypes().setAll(makePaymentButton, ButtonType.CANCEL);

		    confirmationAlert.showAndWait().ifPresent(response -> {
		        if (response == makePaymentButton) {
		        	completeCheckout();
		        	updateDetails(selectedCart);
		        	hideDetails();
		        }
		    });
		
	}

	private void DeleteCart() {
		
		try (Connection connection = DatabaseConnect.getConnection();
		         PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM cart WHERE UserID = ? AND HoodieID = ?")) {

		        preparedStatement.setString(1, currentuser.getUserid());
		        preparedStatement.setString(2, selectedCart.getHoodieID());
		        preparedStatement.executeUpdate();
		        
		        updateCartTotal();
		        tv.getItems().remove(selectedCart);
		        
		    } catch (SQLException ex) {
		        showErrorAlert("Error clearing the cart: " + ex.getMessage());
		    }
		
	}

	private void updateCartTotal() {
		 ObservableList<Cart> cartList = getCartData(currentuser);
		 double cartTotal = calculateCartTotal(cartList);
         lblcarttot.setText("Cart's Total Price: " + String.format("%.2f", cartTotal));
	}

	private void Layout() {

		gp.add(lbljudul, 0, 0);
		gp.add(tv , 0, 1, 1 ,16);
		gp.add(lbldetail, 1, 1);
		gp.add(lblnone, 1, 2);
		gp.add(lblcontact, 1, 9);
		gp.add(lblemail, 1, 10);
		gp.add(lblphone, 1, 11);
		gp.add(lbladdress, 1, 12);
		gp.add(lblcarttot, 1, 14);
		gp.add(btco, 1, 15);
		
	}

	private void Initialize() {
		
		gp = new GridPane();
		bp = new BorderPane(gp);
		gp.setAlignment(Pos.CENTER);
		
		lbljudul = new Label (currentuser.getUsername() + "'S Cart");
		lbljudul.setStyle("-fx-font-size: 40; -fx-font-style: italic;");
		lbldetail = new Label ("Hoodie's Detail");
		lbldetail.setStyle("-fx-font-size: 25; -fx-font-weight: bold; -fx-font-style: italic;");
		lblid = new Label ("Hoodie ID: ");
		lblname = new Label ("Name: ");
		lblprice = new Label ("Price: ");
		lblqty = new Label ("Quantity: ");
		lbltotprice = new Label ("Total Price: ");
		lblcontact = new Label ("Contact Information");
		lblcontact.setStyle("-fx-font-size: 25; -fx-font-weight: bold; -fx-font-style: italic;");
		lblemail = new Label ("Email : " + currentuser.getEmail());
		lblphone = new Label ("Phone : " + currentuser.getPhonenumber());
		lbladdress = new Label ("Address : " + currentuser.getAddress());
		lblcarttot = new Label ("Cart's Total Price: "  );
		lblcarttot.setStyle("-fx-font-size: 25; -fx-font-weight: bold; -fx-font-style: italic;");
		lblnone = new Label ("Select an Item from Table");
		
		tv = new TableView<Cart> ();
		
		btco = new Button ("Checkout");
		btremovecart = new Button ("Remove from Cart");
		
		
		gp.setHgap(10);
		gp.setVgap(5);
		
		menubar = new MenuBar();
		
		accountmenu = new Menu ("Account");
		logoutitem = new MenuItem ("Log Out");
		
		menu = new Menu ("User");
		homeitem = new MenuItem ("Home");
		cartitem = new MenuItem ("Cart");
		historyitem = new MenuItem ("History");
		
		accountmenu.getItems().addAll(logoutitem);
		menu.getItems().addAll(homeitem, cartitem, historyitem);
		
		menubar.getMenus().addAll(accountmenu, menu);
		
		bp = new BorderPane (gp);
		bp.setTop(menubar);
		
	}

}
