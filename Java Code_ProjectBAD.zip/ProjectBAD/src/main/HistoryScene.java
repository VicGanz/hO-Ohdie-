package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.Transaction;
import model.TransactionDetail;
import model.User;
import util.DatabaseConnect;

public class HistoryScene extends Application{
	
	Scene historyscene;
	BorderPane bp;
	GridPane gp;
	
	TableView<Transaction> tv;
	TableView<TransactionDetail> tvd;
	
	Label lbltransaction, lbldetail, lbltotprice, lblselect;
	
	MenuBar menubar;
	MenuItem logoutitem, homeitem, cartitem, historyitem;
	Menu accountmenu, menu;
	Stage historystage;
	
	private User currentuser;
	private Transaction selectedTransaction;
	

	public static void main(String[] args) {
		launch(args);
	}
	
	public HistoryScene(User currentuser) {
        this.currentuser = currentuser;
    }

	@Override
	public void start(Stage historystage) throws Exception {
		
		this.historystage = historystage;
		Initialize();
		Layout();
		displayTransaction();
		Action();
		historyscene = new Scene (bp, 720, 600);
		historystage.setTitle("hO-Odie");
		historystage.setScene(historyscene);
		historystage.show();
		
	}
	
	private void displayTransaction(){
		
		getTransactionData(currentuser);
		
		tv.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) { 
                updateDetails(newSelection);
            } else {
            	selectedTransaction = null;
                hideDetails();
            }
        });
		
		TableColumn<Transaction, String> transactionID = new TableColumn<>("Transaction ID");
		transactionID.setCellValueFactory(new PropertyValueFactory<>("TransactionID"));
		transactionID.setPrefWidth(130);

        TableColumn<Transaction, String> userID = new TableColumn<>("User ID");
        userID.setCellValueFactory(new PropertyValueFactory<>("UserID"));
        userID.setPrefWidth(130);
        
        tv.getColumns().addAll(transactionID, userID);
        
        ObservableList<Transaction> trlist = getTransactionData(currentuser);
        tv.setItems(trlist);

		
	}

	private ObservableList<Transaction> getTransactionData(User currentUser) {
		try (Connection connection = DatabaseConnect.getConnection();
		         PreparedStatement preparedStatement = connection.prepareStatement(
		                 "SELECT * FROM transactionheader WHERE UserID = ?")) {

		        preparedStatement.setString(1, currentUser.getUserid());

		        try (ResultSet resultSet = preparedStatement.executeQuery()) {
		            ObservableList<Transaction> trlist = FXCollections.observableArrayList();

		            while (resultSet.next()) {
		                String transactionID = resultSet.getString("TransactionID");
		                String userID = resultSet.getString("UserID");

		                trlist.add(new Transaction(transactionID, userID));
		                
		            }
		            return trlist;
		        }

		    } catch (SQLException ex) {
		        showErrorAlert("Database Error: " + ex.getMessage());
		    }
		    return FXCollections.observableArrayList();
		
	}

	private void showErrorAlert(String message) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
		    alert.setTitle("Error");
		    alert.setHeaderText(null);
		    alert.setContentText(message);
		    alert.showAndWait();
		
	}

	private void hideDetails() {
		
		lblselect.setVisible(true);
		
	}

	private void updateDetails(Transaction selectedTransaction) {
		
		tvd.getItems().clear();
		tvd.getColumns().clear();
		getDetailData(selectedTransaction);

		TableColumn<TransactionDetail, String> transactionID = new TableColumn<>("Transaction ID");
		transactionID.setCellValueFactory(new PropertyValueFactory<>("TransactionID"));
		transactionID.setPrefWidth(90);

        TableColumn<TransactionDetail, String> hoodieID = new TableColumn<>("Hoodie ID");
        hoodieID.setCellValueFactory(new PropertyValueFactory<>("HoodieID"));
        hoodieID.setPrefWidth(70);

        TableColumn<TransactionDetail, String> hoodieName = new TableColumn<>("Hoodie Name");
        hoodieName.setCellValueFactory(new PropertyValueFactory<>("HoodieName"));
        hoodieName.setPrefWidth(90);
        
        TableColumn<TransactionDetail, Integer> quantity = new TableColumn<>("Quantity");
        quantity.setCellValueFactory(new PropertyValueFactory<>("Quantity"));
        quantity.setPrefWidth(70);
        
        TableColumn<TransactionDetail, Double> totalPrice = new TableColumn<>("Total Price");
        totalPrice.setCellValueFactory(new PropertyValueFactory<>("TotalPrice"));
        totalPrice.setPrefWidth(90);
        
        tvd.getColumns().addAll(transactionID, hoodieID, hoodieName, quantity, totalPrice);
        
        ObservableList<TransactionDetail> detaillist = getDetailData(selectedTransaction);
        tvd.setItems(detaillist);
        
        double totalTransactionPrice = totalTransactionPrice(detaillist);
        lbltotprice.setText("Total Price: " + totalTransactionPrice);
        lbltotprice.setStyle("-fx-font-size: 25;");
        lbltotprice.setAlignment(Pos.BOTTOM_RIGHT);
        
        lbldetail.setText(selectedTransaction.getTransactionID() + " Transaction Detail");
        gp.add(lbldetail, 1, 0);
        gp.add(tvd, 1, 1);
        gp.add(lbltotprice, 1, 3);
        
        lblselect.setVisible(false);

	}

	private double totalTransactionPrice(ObservableList<TransactionDetail> detaillist) {
		double total = 0.0;
	    for (TransactionDetail detail : detaillist) {
	        total += detail.getTotalPrice();
	    }
	    return total;
	}

	private ObservableList<TransactionDetail> getDetailData(Transaction selectedTransaction) {
		try (Connection connection = DatabaseConnect.getConnection();
		         PreparedStatement preparedStatement = connection.prepareStatement(
		                 "SELECT td.TransactionID, td.HoodieID, td.Quantity, h.HoodieName, (td.Quantity * h.HoodiePrice) AS 'Total Price' " + 
		                 "FROM transactiondetail td " + 
		                 "JOIN hoodie h ON td.HoodieID = h.HoodieID " + 
		                 "WHERE td.TransactionID = ?")) {

		        preparedStatement.setString(1, selectedTransaction.getTransactionID());

		        try (ResultSet resultSet = preparedStatement.executeQuery()) {
		            ObservableList<TransactionDetail> detaillist = FXCollections.observableArrayList();

		            while (resultSet.next()) {
		                String transactionID = resultSet.getString("TransactionID");
		                String hoodieID = resultSet.getString("HoodieID");
		                String hoodieName = resultSet.getString("HoodieName");
		                int quantity = resultSet.getInt("Quantity");
		                double totalPrice = resultSet.getDouble("Total Price");

		                detaillist.add(new TransactionDetail(transactionID, hoodieID, hoodieName, quantity, totalPrice));
		                
		            }
		            return detaillist;
		        }

		    } catch (SQLException ex) {
		        showErrorAlert("Database Error: " + ex.getMessage());
		    }
		    return FXCollections.observableArrayList();
	}

	private void Action() {
		
		homeitem.setOnAction(e -> {
            HomeScene homescene = new HomeScene(currentuser);
            try {
            	homescene.start(historystage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        });
		
		cartitem.setOnAction(e -> {
            CartScene cartscene = new CartScene(currentuser);
            try {
				cartscene.start(historystage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        });
		
		logoutitem.setOnAction(e ->{
			
			LoginScene loginscene = new LoginScene();
			try {
				loginscene.start(historystage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		});
		
	}

	private void Layout() {
		
		gp.add(lbltransaction, 0, 0);
		gp.add(tv, 0, 1);
		gp.add(lblselect, 1, 0);
		
		gp.setPadding(new Insets (10));
		gp.setHgap(10);
		gp.setVgap(5);
		gp.setAlignment(Pos.CENTER);
		
		
	}

	private void Initialize() {
		
		gp = new GridPane ();
		bp = new BorderPane(gp);
		
		lbltransaction = new Label (currentuser.getUsername() + " Transaction(s)");
		lbltransaction.setStyle("-fx-font-size: 25; -fx-font-weight: bold; -fx-font-style: italic;");
		lbldetail = new Label ("Transaction Detail");
		lbldetail.setStyle("-fx-font-size: 25; -fx-font-weight: bold; -fx-font-style: italic;");
		lbltotprice = new Label ("Total Price: ");
		lblselect = new Label ("(Select a Transaction)");
		lblselect.setStyle("-fx-font-size: 25; -fx-font-weight: bold; -fx-font-style: italic;");
		
		tv = new TableView<Transaction>();
		tv.setFixedCellSize(25);
		
		tvd = new TableView<TransactionDetail>();
		tvd.setFixedCellSize(25);
		
		menubar = new MenuBar();
		
		accountmenu = new Menu ("Account");
		logoutitem = new MenuItem ("Log Out");
		
		menu = new Menu ("User");
		homeitem = new MenuItem ("Home");
		cartitem = new MenuItem ("Cart");
		historyitem = new MenuItem ("History");
		
		accountmenu.getItems().addAll(logoutitem);
		menu.getItems().addAll(homeitem, cartitem, historyitem);
		
		menubar.getMenus().addAll(accountmenu, menu);
		
		bp = new BorderPane (gp);
		bp.setTop(menubar);
	}

}
