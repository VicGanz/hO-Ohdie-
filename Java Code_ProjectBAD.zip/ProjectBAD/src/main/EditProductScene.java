package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Hoodie;
import util.DatabaseConnect;

public class EditProductScene extends Application {
	
	Scene EditScene;
	BorderPane bp;
	GridPane gp;
	Label lbljudul, lblud, lblinsert, lblname,lblprice,lblid, lblname2, lblprice2, lblselect;
	Button btupdate, btdelete, btinsert;
	TextField tfpriceu, tfname, tfpricei;
	TableView<Hoodie> tv;
	Menu accountmenu, adminmenu;
	MenuItem logoutitem, editproductitem;
	MenuBar menubar;
	Stage stage;
	HBox hb, hb1, hb2, hb3;
	
	private Hoodie selectedHoodie;
	

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		
		this.stage = stage;
		Initialize();
		Layout();
		Action();
		displayHoodie();
		EditScene = new Scene (bp, 750, 600);
		stage.setTitle("hO-Odie");
		stage.setScene(EditScene);
		stage.show();
		
		
	}

	private void Action() {

		logoutitem.setOnAction(e ->{
			
			LoginScene loginscene = new LoginScene();
			try {
				loginscene.start(stage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		});
		
		btupdate.setOnAction(e -> {
			updateHoodie();
		});
		
		btdelete.setOnAction(e -> {
			deleteHoodie();
		});
		
		btinsert.setOnAction(e -> {
		    InsertHoodie();
		});
		
	}
	

	private void displayHoodie() {
		
		hoodieTableView();
		
		tv.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) { 
            	selectedHoodie = newSelection;
                updateDetails(newSelection);
            } else {
            	selectedHoodie = null;
                hideDetails();
            }
        });
		
		TableColumn<Hoodie, String> hoodieID = new TableColumn<>("Hoodie ID");
		hoodieID.setCellValueFactory(new PropertyValueFactory<>("HoodieID"));
		hoodieID.setPrefWidth(130);

        TableColumn<Hoodie, String> hoodieName = new TableColumn<>("Hoodie Name");
        hoodieName.setCellValueFactory(new PropertyValueFactory<>("HoodieName"));
        hoodieName.setPrefWidth(130);
        
        TableColumn<Hoodie, Double> hoodiePrice = new TableColumn<>("Hoodie Price");
        hoodiePrice.setCellValueFactory(new PropertyValueFactory<>("HoodiePrice"));
        hoodiePrice.setPrefWidth(130);
        
       
        
        tv.getColumns().addAll(hoodieID, hoodieName, hoodiePrice);
        
        ObservableList<Hoodie> hoodieList = hoodieTableView();
        tv.setItems(hoodieList);

	}
	
	private void hideDetails() {
		
		lblselect.setVisible(true);
		lblid.setVisible(false);
		lblname.setVisible(false);
		hb.setVisible(false);
		hb1.setVisible(false);
		
		
	}

	private void updateDetails(Hoodie selectedHoodie) {
		
		   lblid.setText("Hoodie ID: " + selectedHoodie.getHoodieID());
	       lblname.setText("Name: " + selectedHoodie.getHoodieName());
	       tfpriceu.setText("" + selectedHoodie.getHoodiePrice());
	       
	       gp.getChildren().removeAll(lblid, lblname, hb, hb1);
	       
	       gp.add(lblid, 1, 2);
	       gp.add(lblname, 1, 3);
	       gp.add(hb, 1, 4);
	       gp.add(hb1, 1, 5);
	       
        lblselect.setVisible(false);
	   	lblid.setVisible(true);
		lblname.setVisible(true);
		hb.setVisible(true);
		hb1.setVisible(true);
		
	}

	private ObservableList<Hoodie> hoodieTableView() {
		try (Connection connection = DatabaseConnect.getConnection();
	             Statement statement = connection.createStatement();
	             ResultSet resultSet = statement.executeQuery("SELECT * FROM hoodie")) {

	            ObservableList<Hoodie> hoodieList = FXCollections.observableArrayList();

	            while (resultSet.next()) {
	                String hoodieID = resultSet.getString("HoodieID");
	                String hoodieName = resultSet.getString("HoodieName");
	                double hoodiePrice = resultSet.getDouble("HoodiePrice");

	                Hoodie hoodie = new Hoodie(hoodieID, hoodieName, hoodiePrice);
	                hoodieList.add(hoodie);
	            }

	            return hoodieList;

	        } catch (SQLException ex) {
	            showErrorAlert("Error fetching hoodie data from the database: " + ex.getMessage());
	        }
		return FXCollections.observableArrayList();
		
	}
	
	private void deleteHoodie() {
		
		try (Connection connection = DatabaseConnect.getConnection();
		         PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM hoodie WHERE HoodieID = ?")) {

		        preparedStatement.setString(1, selectedHoodie.getHoodieID());
		        preparedStatement.executeUpdate();
		        
		        tv.getItems().remove(selectedHoodie);
		        
		    } catch (SQLException ex) {
		        showErrorAlert("Error clearing the cart: " + ex.getMessage());
		    }
		
	}

	private void updateHoodie() {
		
		try (Connection connection = DatabaseConnect.getConnection();
		         PreparedStatement preparedStatement = connection.prepareStatement("UPDATE hoodie SET HoodiePrice = ? WHERE HoodieID = ?")) {
		        
				double newPrice = Double.parseDouble(tfpriceu.getText());
		        preparedStatement.setDouble(1, newPrice);
		        preparedStatement.setString(2, selectedHoodie.getHoodieID());
		        int rowsUpdated = preparedStatement.executeUpdate();
		        
		        if(newPrice <= 0) {
		        	showErrorAlert("Price can't under 0");
		        	return;
		        }

		        if (rowsUpdated > 0) {
		            selectedHoodie.setHoodiePrice(newPrice);
		            tv.refresh(); 
		        } else {
		            showErrorAlert("Failed to update hoodie price.");
		        }
		        
		    } catch (SQLException ex) {
		        showErrorAlert("Error clearing the cart: " + ex.getMessage());
		    }
		
		
	}

	private void InsertHoodie() {
		String hoodieID = generateHoodieID();
		String hoodieName = tfname.getText();
		String hoodiePrice = tfpricei.getText();
		
		if (hoodieName.isEmpty() || hoodiePrice.isEmpty()) {
	        showErrorAlert("Name and Price can't be empty.");
	        return; 
	    }if(!isDecimal(hoodiePrice)) {
	    	showErrorAlert ("Price Must be Decimal Number");
	    	return;
	    }
	    double price = Double.parseDouble(hoodiePrice);
	    if(price <= 0) {
	    	showErrorAlert ("Price Must be >= 0");
	    	return;
	    }
		
		String query = "INSERT INTO hoodie (HoodieID, HoodieName, HoodiePrice) VALUES (?, ?, ?)";
   	 try (Connection connection = DatabaseConnect.getConnection()) {
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, hoodieID);
                preparedStatement.setString(2, hoodieName);
                preparedStatement.setString(3, hoodiePrice);
                
                
                int rowsAffected = preparedStatement.executeUpdate();
                
                if (rowsAffected > 0) {
               	 	
                	tfname.clear();
                	tfpricei.clear();
                	ObservableList<Hoodie> updatedData = hoodieTableView();
                	tv.setItems(updatedData);
                	
                	
                } else {
                    showErrorAlert("Failed to insert data.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showErrorAlert("Database error: " + e.getMessage());
        }
		
	}

	private boolean isDecimal(String hoodiePrice) {
		 try {
		        Double.parseDouble(hoodiePrice);
		        return true;
		    } catch (NumberFormatException e) {
		        return false;
		    }
	}

	private String generateHoodieID() {
	    int randomNumber = (int) (Math.random() * 900) + 100;
	    return "HO" + randomNumber;
	    
	    
	}
	
	private void showErrorAlert(String message) {
	    Alert alert = new Alert(Alert.AlertType.ERROR);
	    alert.setTitle("Error");
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.showAndWait();
	}

	private void Layout() {
		
		hb = new HBox();
		hb1 = new HBox();
		hb2 = new HBox();
		hb3 = new HBox();
		btinsert.setMinWidth(150);
		hb.getChildren().addAll(lblprice, tfpriceu);
		hb.setSpacing(10);
		hb1.getChildren().addAll(btupdate,btdelete);
		hb1.setSpacing(10);
		hb2.getChildren().addAll(lblname2, tfname);
		hb2.setSpacing(10);
		hb3.getChildren().addAll(lblprice2, tfpricei);
		hb3.setSpacing(15);
		
		tfname.setPromptText("Input name");
		tfpricei.setPromptText("Input price");
		
		gp.add(lbljudul, 0, 0);
		gp.add(tv, 0, 1, 1, 12); 
		gp.add(lblud, 1, 1);
		gp.add(lblselect, 1, 2);
		gp.add(lblinsert, 1, 7);
		gp.add(hb2, 1, 8);
		gp.add(hb3, 1, 9);
		gp.add(btinsert, 1, 10);
		GridPane.setMargin(btinsert, new Insets(0, 0, 0, 46)); 
		
		gp.setPadding(new Insets (5));
		gp.setHgap(15);
		gp.setVgap(10);
		gp.setAlignment(Pos.CENTER);
		
		
		
		
	}

	private void Initialize() {
		
		gp = new GridPane();
		bp = new BorderPane(gp);
		
		lbljudul = new Label ("Edit Product");
		lbljudul.setStyle("-fx-font-size: 25; -fx-font-style: italic;");
		lblud = new Label ("Update & Delete Hoodie(s)");
		lblud.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
		lblid = new Label ("Hoodie ID: ");
		lblname = new Label ("Name: ");
		lblprice = new Label ("Price: ");
		lblinsert = new Label ("Insert Hoodie");
		lblinsert.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
		lblname2 = new Label ("Name: ");
		lblprice2 = new Label ("Price: ");
		lblselect = new Label ("Select an item from the List...");
		
		btupdate = new Button ("Update Price");
		btdelete = new Button ("Delete Hoodie");
		btinsert = new Button ("Insert");
		
		tfpriceu = new TextField ();
		tfname = new TextField ();
		tfpricei = new TextField ();
		
		tv = new TableView<Hoodie>();
		
		menubar = new MenuBar();
		accountmenu = new Menu ("Account");
		adminmenu = new Menu ("Admin");
		logoutitem = new MenuItem("Log Out");
		editproductitem = new MenuItem ("Edit Product");
		
		accountmenu.getItems().addAll(logoutitem);
		adminmenu.getItems().addAll(editproductitem);
		menubar.getMenus().addAll(accountmenu,adminmenu);
		
		bp = new BorderPane(gp);
		bp.setTop(menubar);
		
		
	}

}
