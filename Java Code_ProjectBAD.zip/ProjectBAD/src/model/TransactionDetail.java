package model;

public class TransactionDetail {
	
	private String TransactionID;
	private String HoodieID;
	private String HoodieName;
	private int Quantity;
	private double TotalPrice;
	
	public TransactionDetail(String transactionID, String hoodieID, String hoodieName, int quantity, double totalPrice) {
		super();
		TransactionID = transactionID;
		HoodieID = hoodieID;
		HoodieName = hoodieName;
		Quantity = quantity;
		TotalPrice = totalPrice;
	}

	public String getTransactionID() {
		return TransactionID;
	}

	public void setTransactionID(String transactionID) {
		TransactionID = transactionID;
	}

	public String getHoodieID() {
		return HoodieID;
	}

	public void setHoodieID(String hoodieID) {
		HoodieID = hoodieID;
	}

	public String getHoodieName() {
		return HoodieName;
	}

	public void setHoodieName(String hoodieName) {
		HoodieName = hoodieName;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public double getTotalPrice() {
		return TotalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		TotalPrice = totalPrice;
	}
	
	
	
	

}
