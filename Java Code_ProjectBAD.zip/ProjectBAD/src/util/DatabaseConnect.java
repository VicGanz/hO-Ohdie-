package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnect {

    private static final String URL = "jdbc:mysql://localhost:3306/hoohdie";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
    ResultSet rs;
    Statement st;

    public static Connection getConnection() throws SQLException {
    	try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
    	}catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found");
        }
       
    }
    

}