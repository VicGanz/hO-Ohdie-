package main;

import java.sql.*;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.stage.Stage;
import model.User;
import util.DatabaseConnect;

public class LoginScene extends Application{
	
	
	
	BorderPane bp;
	GridPane gp;
	Scene loginScene;
	Label loginlbl , usernamelbl, passwordlbl;
	TextField usernamefield;
	PasswordField passwordfield;
	Button loginbutton;
	MenuBar menubar;
	MenuItem registeritem;
	Menu filemenu;
	Stage primaryStage;

	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage p) throws Exception {
		
		this.primaryStage = p;
		initialize();
		Action();
		loginScene = new Scene(bp,700,600);
		primaryStage.setScene(loginScene);
		primaryStage.setTitle("hO-Ohdie");
		primaryStage.show();
		
	}

	private void Action() {
	    registeritem.setOnAction(e -> {
	        RegisterScene registerScene = new RegisterScene();
	        try {
	            registerScene.start(primaryStage);
	        } catch (Exception e1) {
	            e1.printStackTrace(); 
	        }
	    });
	    
	    loginbutton.setOnAction(e -> {
	    	
            String username = usernamefield.getText();
            String password = passwordfield.getText();

            if (validateCredentials(username, password)) {
                String role = getUserRole(username);

                if ("User".equals(role)) {
                	User currentuser = loginByUsername(username);
                	HomeScene homescene = new HomeScene(currentuser);
                    try {
                    	homescene.start(primaryStage);
        			} catch (Exception e1) {
        				// TODO Auto-generated catch block
        				e1.printStackTrace();
        				
        			}
                } else if ("Admin".equals(role)) {
                	
                	EditProductScene editscene = new EditProductScene();
                    try {
                    	editscene.start(primaryStage);
        			} catch (Exception e1) {
        				// TODO Auto-generated catch block
        				e1.printStackTrace();
        			}
                    
                }
            } else {
                showErrorAlert();
            }
        });
    }

    private User loginByUsername(String username) {
    	 try (Connection connection = DatabaseConnect.getConnection()) {
    	        String query = "SELECT * FROM user WHERE username = ?";
    	        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
    	            preparedStatement.setString(1, username);

    	            try (ResultSet resultSet = preparedStatement.executeQuery()) {
    	                if (resultSet.next()) {
    	                    String userId = resultSet.getString("userid");
    	                    String email = resultSet.getString("email");
    	                    String password = resultSet.getString("password");
    	                    String phonenumber = resultSet.getString("phonenumber");
    	                    String address = resultSet.getString("address");
    	                    String gender = resultSet.getString("gender");
    	                    String role = resultSet.getString("role");
    	                    return new User(userId, email, username, password, phonenumber, address, gender, role);
    	                }
    	            }
    	        }
    	    } catch (SQLException e) {
    	        e.printStackTrace();
    	        return null;
    	    }
		return null;
	}

	private boolean validateCredentials(String username, String password) {
        try (Connection connection = DatabaseConnect.getConnection()) {
            String query = "SELECT Username, Password FROM user WHERE username = ? AND password = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, password);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    return resultSet.next();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private String getUserRole(String username) {
        try (Connection connection = DatabaseConnect.getConnection()) {
            String query = "SELECT role FROM user WHERE username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        return resultSet.getString("role");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return null;
    }


	private void showErrorAlert() {
		 Alert alert = new Alert(Alert.AlertType.ERROR);
	        alert.setTitle("Errror");
	        alert.setHeaderText("Error");
	        alert.setContentText("Wrong Credential");
	        alert.showAndWait();
		
	}

	private void initialize() {
		
		loginlbl = new Label ("LOGIN");
		loginlbl.setStyle("-fx-font-size: 50; -fx-font-weight: bold; -fx-font-style: italic;");
		usernamelbl = new Label ("Username: ");
		passwordlbl = new Label ("Password: ");
		loginbutton = new Button ("Login");
		loginbutton.setMinWidth(220);
		usernamefield = new TextField();
		usernamefield.setPromptText("Input Username");
		passwordfield = new PasswordField();
		passwordfield.setPromptText("Input Password");
		
		gp = new GridPane ();
		gp.setVgap(10);
		gp.setHgap(10);
		gp.add(loginlbl, 0, 0,5,1);
		gp.add(usernamelbl, 0, 1);
		gp.add(usernamefield, 1, 1);
		gp.add(passwordfield, 1, 2);
		gp.add(passwordlbl, 0, 2);
		gp.add(loginbutton, 0, 3 ,5,5);
		gp.setAlignment(Pos.CENTER);
		
		VBox vb = new VBox(gp);
		vb.setSpacing(100);
		vb.setPadding(new Insets(10,10, 10, 10));
		vb.setAlignment(Pos.CENTER);
		
		menubar = new MenuBar ();
		filemenu = new Menu ("Login");
		registeritem = new MenuItem("Register");
		
		filemenu.getItems().addAll(registeritem);
		menubar.getMenus().add(filemenu);
		
		bp = new BorderPane(gp);
		bp.setTop(menubar);
		
		
	}

	

	
}
